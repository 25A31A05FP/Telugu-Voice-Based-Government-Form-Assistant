# Algorithm and Working Method

## 1. Overall Processing Pipeline

The system follows a sequence of stages:

``` text
User Uploads Form / Provides Supported URL
                    |
                    v
          File and URL Validation
                    |
                    v
       Document Type Identification
                    |
          +---------+---------+
          |                   |
          v                   v
   Digital Document       Scanned/Image
   Text Extraction           OCR
          |                   |
          +---------+---------+
                    |
                    v
          Extracted Text + Layout
                    |
                    v
       Form Question/Field Detection
                    |
                    v
       Structured Dynamic Field List
                    |
                    v
       Telugu Question Generation
                    |
                    v
       Telugu Voice / Typed Answer
                    |
                    v
        Speech-to-Text (if voice)
                    |
                    v
       Answer Understanding / Extraction
                    |
                    v
        Translation (when required)
                    |
                    v
          Semantic Field Mapping
                    |
                    v
          Validation and Confirmation
                    |
                    v
          User Review and Editing
                    |
                    v
          PDF Filling / Generation
                    |
                    v
             Preview and Download
```

## 2. Algorithm 1: Document Input and Validation

**Input:** Uploaded file or user-provided URL.

**Method:** 1. Receive the file or URL. 2. Check file extension, MIME
type, file size, and basic integrity. 3. Reject unsupported or unsafe
files. 4. Identify whether the input is PDF, image, DOCX, or supported
web content. 5. Store the file securely for temporary processing. 6.
Pass it to the appropriate extraction module.

**Output:** Validated document ready for processing.

## 3. Algorithm 2: Text Extraction and OCR

**Input:** Validated document.

**Method:** 1. If the PDF contains selectable text, extract text and
page information using a PDF parser. 2. If the page is scanned or
image-based, render the page as an image. 3. Run OCR on the image. 4.
Retain page numbers and, where available, text positions or bounding
boxes. 5. Combine extracted text in document order. 6. Flag
low-confidence or unreadable text for user review.

**Output:** Extracted text and available layout information.

**Important:** OCR is not guaranteed to read every scan correctly.
Low-quality images, handwriting, tables, and unusual fonts may require
correction.

## 4. Algorithm 3: Dynamic Form Field Detection

**Input:** Extracted document text and layout.

**Method:** 1. Split the document into sections and candidate questions.
2. Detect labels, instructions, blank lines, checkboxes, tables, and
existing PDF form fields. 3. Classify each candidate field, for
example: - Name - Date - Email - Phone - Address - Education -
Number/percentage - Checkbox - Long-text answer 4. Detect whether the
field appears required or optional from nearby instructions and document
cues. 5. Infer the expected answer format where possible. 6. Create a
structured field object.

**Example structured field:**

``` json
{
  "field_id": "applicant_full_name",
  "label": "Name of the Applicant",
  "field_type": "text",
  "required": true,
  "expected_language": "English",
  "source_page": 1,
  "confidence": 0.94
}
```

The confidence value must come from the actual extraction or
classification process. Do not use a made-up confidence score.

**Output:** Dynamic list of fields for user confirmation.

## 5. Algorithm 4: Telugu Question Generation

**Input:** A detected field label and its instructions.

**Method:** 1. Read the field label and supporting instructions. 2.
Translate or explain the question in simple Telugu. 3. Preserve
important names, numbers, dates, and technical terms. 4. Generate a
short question that asks only for the required information. 5. Send the
question to Telugu text-to-speech. 6. Display the text so the user can
read it as well.

**Example:**

-   Form label: `Enter your date of birth`
-   Telugu question: `మీ పుట్టిన తేదీ చెప్పండి.`
-   Expected answer: Date

## 6. Algorithm 5: Telugu Speech Recognition

**Input:** User's recorded Telugu audio.

**Method:** 1. Request microphone permission. 2. Record audio only after
the user starts the microphone. 3. Send audio to the configured
speech-recognition engine. 4. Receive the recognised text. 5. Display
the transcript to the user. 6. Allow the user to correct the transcript.
7. Continue only after the answer is confirmed or sufficiently clear.

**Output:** Telugu text transcript.

## 7. Algorithm 6: Answer Extraction and Translation

**Input:** User's typed answer or speech transcript, plus target field
details.

**Method:** 1. Identify the information requested by the current field.
2. Extract the relevant value from the user's response. 3. Remove
conversational wording without changing the meaning. 4. Determine the
language required by the target field. 5. If translation is needed,
translate the extracted value. 6. Keep the original answer available for
review. 7. Ask a clarification question if the value is ambiguous.

**Example:**

-   User says: `నా పేరు బాబి కొప్పనాతి`
-   Extracted value: `బాబి కొప్పనాతి`
-   English rendering (if the user confirms this spelling):
    `Babi Koppanathi`

Names must not be transliterated or altered without user confirmation
when spelling matters.

## 8. Algorithm 7: Semantic Field Mapping

**Input:** Extracted answer, current question, and detected field list.

**Method:** 1. Identify the meaning of the current question. 2. Compare
it with candidate field labels and descriptions. 3. Use exact label
matching first when reliable. 4. Otherwise use semantic similarity or an
AI classification model. 5. Check the expected data type and nearby
context. 6. Select the best candidate only if confidence meets the
configured threshold. 7. If multiple fields are plausible, ask the user
to choose. 8. Show the proposed mapping before committing it.

**Example:**

  Detected form label    Information category
  ---------------------- ----------------------
  Applicant Name         Full name
  Student's Name         Full name
  Date of Birth          DOB
  Name of Institution    College/Institution
  Aggregate Percentage   Percentage

**Output:** A proposed mapping between user answers and document fields.

## 9. Algorithm 8: Field Validation

**Input:** Proposed field value and field rules.

**Method:** 1. Check whether required information is present. 2. Check
data type and format. 3. Validate email syntax, date format, and numeric
values where applicable. 4. Check configured length or range
constraints. 5. If invalid, explain the issue in Telugu and request
correction. 6. Do not silently modify important personal information.

**Output:** Validated value or a correction request.

## 10. Algorithm 9: User Review

**Input:** All mapped and validated answers.

**Method:** 1. Display every detected field and proposed answer. 2.
Highlight missing, uncertain, or invalid fields. 3. Allow the user to
edit any value. 4. Re-run validation after edits. 5. Require
confirmation before generating the final document.

**Output:** User-approved set of answers.

## 11. Algorithm 10: PDF Filling and Generation

**Input:** Original document, field map, and approved answers.

**Method:** 1. Check whether the PDF has editable AcroForm fields. 2. If
editable fields exist, map values to those fields. 3. If no editable
fields exist, use page layout and detected positions to place text, or
generate a new completed document. 4. Embed or use fonts that support
Telugu Unicode. 5. Preserve the original layout as far as possible. 6.
Generate the output PDF. 7. Reopen and verify that the generated file is
readable. 8. Show the preview and provide a download option.

**Output:** Completed document for user review.

## 12. Simplified Pseudocode

``` text
START

Receive uploaded document or supported URL

Validate input
IF input is unsupported:
    Show error
    STOP

Extract document text and layout

IF document is scanned or image-based:
    Run OCR

Detect questions and form fields
Create dynamic field list
Show fields for confirmation

FOR each required field:
    Generate Telugu question
    Speak question or display text

    Receive voice or typed answer

    IF voice answer:
        Convert speech to text

    Extract answer value

    IF translation is required:
        Translate value
        Preserve original answer

    Map answer to correct field

    Validate answer

    IF answer is missing, invalid, or ambiguous:
        Ask user to correct or clarify
    ELSE:
        Save proposed field value

Show completed form for review
Allow edits
Validate edited values

IF user approves:
    Fill supported PDF or generate completed document
    Verify generated PDF
    Display preview and download option

END
```

## 13. Key Methods Used

  Method                  Purpose
  ----------------------- ----------------------------------------------
  PDF/DOCX parsing        Read digital documents
  OCR                     Extract text from scanned documents
  NLP                     Understand questions and answers
  Text classification     Identify field categories
  Semantic similarity     Match different labels with similar meanings
  Speech-to-Text          Convert Telugu speech into text
  Text-to-Speech          Ask questions using Telugu audio
  Machine translation     Convert Telugu and English text when needed
  Rule-based validation   Check answer formats and required values
  PDF form filling        Place answers into supported PDF fields

## 14. Accuracy and Error Handling

-   Ask the user when a question is unclear.
-   Show OCR text that may be incorrect.
-   Never guess missing personal details.
-   Never silently change names, dates, marks, or qualifications.
-   Preserve the original answer when translation is used.
-   Require user review before final document generation.
-   Keep external website submission under the user's control.
